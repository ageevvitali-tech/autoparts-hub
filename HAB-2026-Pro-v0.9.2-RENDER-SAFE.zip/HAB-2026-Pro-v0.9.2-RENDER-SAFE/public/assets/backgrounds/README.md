# ХАБ-2026 — generated background sectors

Локальный набор AI-сгенерированных изображений для визуального слоя AutoParts Hub.

Сектора: cars, moto, truck, trailer, bus, commercial, special, universal, parts, scene-dynamic, lighting-effects, interior, 360, brand.

Все изображения подключаются локально через `/assets/backgrounds/...`; внешних URL нет.
