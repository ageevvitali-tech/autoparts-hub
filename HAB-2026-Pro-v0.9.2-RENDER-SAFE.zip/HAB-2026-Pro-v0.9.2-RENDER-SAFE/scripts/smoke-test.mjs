import {spawn} from 'node:child_process';
const port=18777;const child=spawn(process.execPath,['server.js'],{env:{...process.env,PORT:String(port)},stdio:'ignore'});await new Promise(r=>setTimeout(r,500));
const base=`http://127.0.0.1:${port}`;
const h=await (await fetch(base+'/api/health')).json();if(!h.ok)throw new Error('health');
const c=await (await fetch(base+'/api/catalog?segment=truck&q=DAF')).json();if(!c.results.length)throw new Error('catalog');
const a=await (await fetch(base+'/api/ai/assistant',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({query:'масляный фильтр'})})).json();if(!a.ok)throw new Error('ai');
const html=await (await fetch(base+'/')).text();if(!html.includes('AutoParts Hub')||!html.includes('hab-background-catalog'))throw new Error('html');
child.kill();console.log('SMOKE OK');
